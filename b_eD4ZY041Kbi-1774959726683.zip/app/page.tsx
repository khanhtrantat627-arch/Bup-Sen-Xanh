import { HeroSection } from "@/components/hero-section";
import { StorySection } from "@/components/story-section";
import { FeaturesSection } from "@/components/features-section";
import { PodcastGenerator } from "@/components/podcast-generator";
import { NewsletterSection, Footer } from "@/components/newsletter-section";

// Trang chính - Landing Page Búp Sen Xanh
export default function BupSenXanhPage() {
  return (
    <main className="min-h-screen">
      {/* Phần đầu trang với banner và tiêu đề */}
      <HeroSection />
      
      {/* Phần câu chuyện dự án */}
      <StorySection />
      
      {/* Phần tính năng và hoạt động */}
      <FeaturesSection />
      
      {/* Phần tạo Podcast tri ân - Tính năng cốt lõi */}
      <PodcastGenerator />
      
      {/* Phần đăng ký nhận tin */}
      <NewsletterSection />
      
      {/* Chân trang */}
      <Footer />
    </main>
  );
}
