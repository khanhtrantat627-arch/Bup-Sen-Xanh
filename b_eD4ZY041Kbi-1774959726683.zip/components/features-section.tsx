"use client";

import { motion } from "framer-motion";
import { BookOpen, Gift, Heart, Music, Palette, Users } from "lucide-react";

// Dữ liệu các tính năng/hoạt động của dự án
const features = [
  {
    icon: Gift,
    title: "Trao quà yêu thương",
    description: "Trao tặng quà, sách vở và dụng cụ học tập cho các em nhỏ có hoàn cảnh khó khăn.",
  },
  {
    icon: BookOpen,
    title: "Hỗ trợ học tập",
    description: "Tổ chức các buổi học, dạy kèm và hướng dẫn học tập miễn phí cho các em.",
  },
  {
    icon: Palette,
    title: "Lớp học nghệ thuật",
    description: "Mang đến những lớp học vẽ, thủ công để phát triển tư duy sáng tạo.",
  },
  {
    icon: Music,
    title: "Podcast tri ân",
    description: "Tạo thẻ podcast cá nhân hóa để tri ân những nhà hảo tâm đồng hành.",
  },
  {
    icon: Users,
    title: "Kết nối cộng đồng",
    description: "Xây dựng mạng lưới tình nguyện viên và nhà hảo tâm cùng chung tay.",
  },
  {
    icon: Heart,
    title: "Chăm sóc tinh thần",
    description: "Tổ chức các hoạt động vui chơi, giao lưu để mang lại niềm vui cho các em.",
  },
];

// Component Features Section - Phần tính năng nổi bật
export function FeaturesSection() {
  return (
    <section id="features" className="py-20 bg-muted/50 relative overflow-hidden">
      {/* Hình trang trí nền */}
      <div className="absolute top-1/4 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-0 w-72 h-72 bg-accent/10 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Tiêu đề section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Hoạt động của chúng mình
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Những điều chúng mình đang làm
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-pretty">
            Mỗi hoạt động là một bước tiến nhỏ, góp phần kiến tạo tương lai tươi sáng hơn cho các em nhỏ.
          </p>
        </motion.div>

        {/* Grid các tính năng */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <FeatureCard feature={feature} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Component card cho mỗi tính năng với hiệu ứng Liquid Glass
function FeatureCard({ feature }: { feature: (typeof features)[0] }) {
  return (
    <motion.div
      whileHover={{ y: -5, scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className="group relative h-full"
    >
      {/* Card container */}
      <div className="relative h-full p-6 rounded-2xl bg-card border border-border/50 shadow-lg overflow-hidden">
        {/* Liquid Glass gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/80 via-transparent to-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        {/* Glow effect khi hover */}
        <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 to-accent/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-50 transition-opacity duration-500" />

        <div className="relative z-10">
          {/* Icon */}
          <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
            <feature.icon className="w-7 h-7 text-primary" />
          </div>

          {/* Tiêu đề */}
          <h3 className="text-lg font-semibold text-foreground mb-2">
            {feature.title}
          </h3>

          {/* Mô tả */}
          <p className="text-muted-foreground text-sm leading-relaxed">
            {feature.description}
          </p>
        </div>

        {/* Corner decoration */}
        <div className="absolute -bottom-4 -right-4 w-20 h-20 bg-primary/5 rounded-full group-hover:scale-150 transition-transform duration-500" />
      </div>
    </motion.div>
  );
}
