"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, Send, CheckCircle, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// Component Newsletter Section - Phần đăng ký nhận tin
export function NewsletterSection() {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Xử lý đăng ký
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    setIsLoading(true);
    
    // Giả lập API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    setIsLoading(false);
    setIsSubmitted(true);
  };

  return (
    <section id="newsletter" className="py-20 bg-gradient-to-b from-muted/50 to-background relative overflow-hidden">
      {/* Hình trang trí nền */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl mx-auto text-center"
        >
          {/* Icon */}
          <div className="w-16 h-16 mx-auto mb-6 rounded-2xl bg-primary/10 flex items-center justify-center">
            <Mail className="w-8 h-8 text-primary" />
          </div>

          {/* Tiêu đề */}
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Đồng hành cùng chúng mình
          </h2>
          <p className="text-muted-foreground mb-8 text-pretty">
            Đăng ký nhận tin để cập nhật những hoạt động mới nhất của Búp Sen Xanh và cùng nhau lan tỏa yêu thương.
          </p>

          {/* Form đăng ký */}
          {!isSubmitted ? (
            <motion.form
              onSubmit={handleSubmit}
              className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
              initial={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <div className="relative flex-1">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="email"
                  placeholder="Nhập email của bạn"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 h-12 bg-card border-border/50 focus:border-primary"
                  required
                />
              </div>
              <Button
                type="submit"
                disabled={isLoading}
                className="h-12 px-6 font-medium gap-2"
              >
                {isLoading ? (
                  <>
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    >
                      <Send className="w-5 h-5" />
                    </motion.div>
                    Đang gửi...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Đăng ký
                  </>
                )}
              </Button>
            </motion.form>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center gap-4 p-6 rounded-2xl bg-primary/10 border border-primary/20"
            >
              <CheckCircle className="w-12 h-12 text-primary" />
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-1">
                  Đăng ký thành công!
                </h3>
                <p className="text-muted-foreground text-sm">
                  Cảm ơn bạn đã đồng hành cùng Búp Sen Xanh.
                </p>
              </div>
            </motion.div>
          )}

          {/* Thông tin bổ sung */}
          <p className="mt-4 text-xs text-muted-foreground">
            Chúng mình cam kết bảo mật thông tin của bạn và chỉ gửi những nội dung hữu ích.
          </p>
        </motion.div>
      </div>
    </section>
  );
}

// Component Footer
export function Footer() {
  return (
    <footer className="py-12 bg-foreground text-background">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo và tên */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <LotusIconSmall className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="font-bold text-background">Búp Sen Xanh</h3>
              <p className="text-xs text-background/60">CFE Foundation • NEU</p>
            </div>
          </div>

          {/* Thông điệp */}
          <div className="flex items-center gap-2 text-background/70 text-sm">
            <span>Được tạo với</span>
            <Heart className="w-4 h-4 text-primary fill-primary" />
            <span>bởi CFE Foundation</span>
          </div>

          {/* Copyright */}
          <p className="text-sm text-background/60">
            © 2025 Búp Sen Xanh. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}

// Icon hoa sen nhỏ
function LotusIconSmall({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className}>
      <path
        d="M12 4C11 7 10 10 11 12C12 14 13 15 12 17"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <path
        d="M7 9C8 11 10 12 11 13"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M17 9C16 11 14 12 13 13"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M6 18C8 17 10 16 12 16C14 16 16 17 18 18"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
    </svg>
  );
}
