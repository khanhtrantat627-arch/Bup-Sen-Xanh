"use client";

import { motion } from "framer-motion";
import { Heart, Sparkles, Users } from "lucide-react";

// Component Story Section - Phần câu chuyện dự án
export function StorySection() {
  return (
    <section id="story" className="py-20 bg-card relative overflow-hidden">
      {/* Hình trang trí */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-accent/5 rounded-full blur-3xl translate-y-1/2" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Tiêu đề section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Câu chuyện của chúng mình
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground text-balance">
            Hành trình kiến tạo tương lai
          </h2>
        </motion.div>

        {/* Nội dung câu chuyện */}
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            {/* Card với hiệu ứng Liquid Glass */}
            <div className="relative p-8 md:p-12 rounded-3xl bg-gradient-to-br from-card via-card to-secondary/30 border border-border/50 shadow-xl">
              {/* Liquid Glass overlay */}
              <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-white/50 via-transparent to-primary/5 pointer-events-none" />
              
              <div className="relative z-10 space-y-6 text-lg leading-relaxed text-foreground/90">
                <p className="text-pretty">
                  Trong hành trình tới tương lai, đôi khi những bước chân nhỏ bé cần thêm một điểm tựa để vững vàng hơn. 
                  <span className="text-primary font-semibold"> Búp Sen Xanh</span> - dự án thiện nguyện thuộc 
                  <span className="text-primary font-semibold"> Quỹ Kiến tạo Tương lai CFE Foundation</span> (CLB Doanh nhân Tương lai - NEU), 
                  ra đời với sứ mệnh trở thành điểm tựa ấy.
                </p>

                <p className="text-pretty">
                  Chúng mình mang đến sự hỗ trợ cả về vật chất lẫn tinh thần, góp phần giúp các em có thêm cơ hội học tập và theo đuổi ước mơ.
                </p>

                <div className="flex items-center gap-2 text-primary">
                  <Sparkles className="w-5 h-5" />
                  <span className="font-semibold">Kế thừa và tiếp nối hành trình từ mùa trước</span>
                </div>

                <p className="text-pretty">
                  Dự án Búp Sen Xanh vẫn giữ trọn tinh thần nhân văn khi lấy cảm hứng từ hình tượng 
                  <span className="italic text-primary">{" \"búp sen xanh\" "}</span> 
                  - biểu trưng cho những tâm hồn trẻ thơ trong sáng, giản dị nhưng đầy nghị lực.
                </p>

                <p className="text-pretty">
                  Chúng mình tin rằng mỗi em nhỏ, dù trong hoàn cảnh khó khăn, vẫn mang trong mình một 
                  <span className="font-semibold text-primary">{" \"hạt mầm hy vọng\""}</span>, 
                  và dự án ra đời để nuôi dưỡng, tiếp sức, giúp những ước mơ ấy có cơ hội được vươn lên và tỏa sáng.
                </p>
              </div>

              {/* Quote decoration */}
              <div className="absolute -top-4 -left-2 text-6xl text-primary/20 font-serif">
                {'"'}
              </div>
              <div className="absolute -bottom-8 -right-2 text-6xl text-primary/20 font-serif rotate-180">
                {'"'}
              </div>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="grid grid-cols-3 gap-4 mt-12"
          >
            {[
              { icon: Heart, label: "Tình yêu thương", value: "Vô hạn" },
              { icon: Users, label: "Tình nguyện viên", value: "50+" },
              { icon: Sparkles, label: "Ước mơ được gieo", value: "100+" },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.5 + index * 0.1 }}
                className="text-center p-4 md:p-6 rounded-2xl bg-secondary/50 border border-border/30"
              >
                <stat.icon className="w-6 h-6 md:w-8 md:h-8 mx-auto mb-2 text-primary" />
                <div className="text-xl md:text-2xl font-bold text-foreground">{stat.value}</div>
                <div className="text-xs md:text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
