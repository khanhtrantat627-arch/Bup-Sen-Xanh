"use client";

import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";

// Component Hero Section - Phần đầu trang với banner và tiêu đề chính
export function HeroSection() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden">
      {/* Nền gradient với hiệu ứng */}
      <div className="absolute inset-0 bg-gradient-to-b from-secondary via-background to-muted" />
      
      {/* Các hình tròn trang trí mờ */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/20 rounded-full blur-3xl" />
      
      <div className="relative z-10 container mx-auto px-4 py-16 text-center">
        {/* Logo CFE Foundation */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-card/80 backdrop-blur-md border border-border/50 shadow-lg">
            <LotusIcon className="w-8 h-8 text-primary" />
            <span className="text-sm font-medium text-muted-foreground">
              CFE Foundation • NEU
            </span>
          </div>
        </motion.div>

        {/* Banner hình ảnh với hiệu ứng Liquid Glass */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative mx-auto mb-10 max-w-4xl"
        >
          <div className="relative aspect-video rounded-2xl overflow-hidden shadow-2xl">
            {/* Liquid Glass overlay */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-accent/20 z-10" />
            <div className="absolute inset-0 backdrop-blur-[1px] z-10 opacity-30" />
            
            {/* Banner placeholder - Thay thế bằng ảnh thực tế */}
            <div className="w-full h-full bg-gradient-to-br from-primary/30 via-secondary to-accent/40 flex items-center justify-center">
              <div className="text-center p-8">
                <LotusIcon className="w-24 h-24 mx-auto text-primary/60 mb-4" />
                <p className="text-muted-foreground text-sm">Banner 16:9 - Ảnh dự án</p>
              </div>
            </div>
            
            {/* Viền Liquid Glass */}
            <div className="absolute inset-0 rounded-2xl border border-white/30 z-20 pointer-events-none" />
          </div>
        </motion.div>

        {/* Tiêu đề chính */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 text-balance"
        >
          <span className="bg-gradient-to-r from-primary via-primary to-accent bg-clip-text text-transparent">
            BÚP SEN XANH
          </span>
          <br />
          <span className="text-foreground text-3xl md:text-4xl lg:text-5xl">
            GIEO HY VỌNG, VẼ TƯƠNG LAI
          </span>
        </motion.h1>

        {/* Phụ đề */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 text-pretty"
        >
          Dự án thiện nguyện thuộc Quỹ Kiến tạo Tương lai CFE Foundation
        </motion.p>

        {/* Nút cuộn xuống */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          onClick={() => {
            document.getElementById("story")?.scrollIntoView({ behavior: "smooth" });
          }}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-all hover:scale-105 shadow-lg shadow-primary/25"
        >
          Khám phá thêm
          <ChevronDown className="w-5 h-5 animate-bounce" />
        </motion.button>
      </div>

      {/* Wave decoration ở dưới */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg
          viewBox="0 0 1440 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-auto"
          preserveAspectRatio="none"
        >
          <path
            d="M0 120L60 105C120 90 240 60 360 45C480 30 600 30 720 37.5C840 45 960 60 1080 67.5C1200 75 1320 75 1380 75L1440 75V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z"
            className="fill-card"
          />
        </svg>
      </div>
    </section>
  );
}

// Icon hoa sen vẽ tay - phong cách trẻ con
function LotusIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Cánh hoa sen - nét vẽ nguệch ngoạc */}
      <path
        d="M32 12C30 18 28 24 30 30C32 36 34 38 32 42"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="opacity-80"
      />
      <path
        d="M20 24C22 28 26 32 30 34C28 30 24 26 20 24Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        fill="currentColor"
        fillOpacity="0.2"
      />
      <path
        d="M44 24C42 28 38 32 34 34C36 30 40 26 44 24Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        fill="currentColor"
        fillOpacity="0.2"
      />
      <path
        d="M14 32C18 34 24 36 30 36C24 34 18 32 14 32Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        fill="currentColor"
        fillOpacity="0.15"
      />
      <path
        d="M50 32C46 34 40 36 34 36C40 34 46 32 50 32Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        fill="currentColor"
        fillOpacity="0.15"
      />
      <path
        d="M32 8C31 14 30 20 31 26C32 32 33 36 32 40"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        fill="currentColor"
        fillOpacity="0.3"
      />
      {/* Lá sen */}
      <path
        d="M18 48C22 46 28 44 32 44C36 44 42 46 46 48C42 50 36 52 32 52C28 52 22 50 18 48Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        fill="currentColor"
        fillOpacity="0.25"
      />
      {/* Nụ nhỏ */}
      <circle cx="32" cy="18" r="4" fill="currentColor" fillOpacity="0.4" />
    </svg>
  );
}
