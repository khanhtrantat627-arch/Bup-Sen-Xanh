"use client";

import { useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Download, Music, Play, Pause, SkipBack, SkipForward, Repeat, Shuffle, Heart, MoreHorizontal, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

// Component chính - Trình tạo Podcast tri ân
export function PodcastGenerator() {
  const [formData, setFormData] = useState({ name: "", gender: "male" });
  const [showCard, setShowCard] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  // Xử lý khi submit form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    setIsGenerating(true);
    
    // Giả lập thời gian tạo
    await new Promise((resolve) => setTimeout(resolve, 800));
    
    setIsGenerating(false);
    setShowCard(true);
  };

  // Xử lý tải ảnh
  const handleDownload = useCallback(async () => {
    if (!cardRef.current) return;

    try {
      // Dynamic import html2canvas
      const html2canvas = (await import("html2canvas")).default;
      
      const canvas = await html2canvas(cardRef.current, {
        scale: 2,
        backgroundColor: "#1a1a1a",
        useCORS: true,
        logging: false,
      });

      const link = document.createElement("a");
      link.download = `bup-sen-xanh-${formData.name.replace(/\s+/g, "-")}.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch (error) {
      console.error("Lỗi khi tải ảnh:", error);
    }
  }, [formData.name]);

  // Reset form để tạo mới
  const handleReset = () => {
    setShowCard(false);
    setFormData({ name: "", gender: "male" });
  };

  // Tạo lời cảm ơn dựa trên giới tính
  const getThankMessage = () => {
    const title = formData.gender === "male" ? "chú" : "cô";
    return `Cảm ơn ${title} ${formData.name} đã đồng hành cùng Búp Sen Xanh!`;
  };

  return (
    <section id="podcast" className="py-20 bg-card relative overflow-hidden">
      {/* Hình trang trí nền */}
      <div className="absolute top-0 left-1/4 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Tiêu đề section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Tính năng đặc biệt
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Tạo Thẻ Podcast Tri Ân
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto text-pretty">
            Nhập thông tin của bạn để tạo thẻ podcast cá nhân hóa - lời tri ân dành cho những tấm lòng vàng đã đồng hành cùng Búp Sen Xanh.
          </p>
        </motion.div>

        {/* Container cho form và card */}
        <div className="max-w-md mx-auto">
          <AnimatePresence mode="wait">
            {!showCard ? (
              // Form nhập liệu
              <motion.div
                key="form"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
              >
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Card form với hiệu ứng Liquid Glass */}
                  <div className="relative p-8 rounded-3xl bg-gradient-to-br from-card via-card to-secondary/20 border border-border/50 shadow-xl">
                    {/* Liquid Glass overlay */}
                    <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-white/40 via-transparent to-primary/5 pointer-events-none" />

                    <div className="relative z-10 space-y-6">
                      {/* Input họ tên */}
                      <div className="space-y-2">
                        <Label htmlFor="name" className="text-foreground font-medium">
                          Họ và tên
                        </Label>
                        <Input
                          id="name"
                          type="text"
                          placeholder="Nhập họ và tên của bạn"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="bg-background/50 border-border/50 focus:border-primary"
                          required
                        />
                      </div>

                      {/* Radio giới tính */}
                      <div className="space-y-3">
                        <Label className="text-foreground font-medium">Giới tính</Label>
                        <RadioGroup
                          value={formData.gender}
                          onValueChange={(value) => setFormData({ ...formData, gender: value })}
                          className="flex gap-6"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="male" id="male" />
                            <Label htmlFor="male" className="cursor-pointer">Nam</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="female" id="female" />
                            <Label htmlFor="female" className="cursor-pointer">Nữ</Label>
                          </div>
                        </RadioGroup>
                      </div>

                      {/* Nút tạo podcast với hiệu ứng pulse */}
                      <Button
                        type="submit"
                        disabled={isGenerating || !formData.name.trim()}
                        className="w-full h-12 text-base font-medium relative overflow-hidden group"
                      >
                        {/* Hiệu ứng glow */}
                        <span className="absolute inset-0 bg-gradient-to-r from-primary via-primary to-accent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        
                        {/* Hiệu ứng pulse */}
                        <span className="absolute inset-0 animate-pulse bg-primary/20 rounded-lg" />
                        
                        <span className="relative z-10 flex items-center justify-center gap-2">
                          {isGenerating ? (
                            <>
                              <motion.div
                                animate={{ rotate: 360 }}
                                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                              >
                                <Music className="w-5 h-5" />
                              </motion.div>
                              Đang tạo...
                            </>
                          ) : (
                            <>
                              <Music className="w-5 h-5" />
                              Tạo Podcast
                            </>
                          )}
                        </span>
                      </Button>
                    </div>
                  </div>
                </form>
              </motion.div>
            ) : (
              // Thẻ Podcast cá nhân hóa
              <motion.div
                key="card"
                initial={{ opacity: 0, y: 30, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5, type: "spring", stiffness: 200 }}
                className="space-y-6"
              >
                {/* Thẻ Podcast - Spotify style */}
                <div
                  ref={cardRef}
                  className="relative rounded-3xl overflow-hidden shadow-2xl bg-gradient-to-b from-[#1a1a1a] to-[#121212]"
                >
                  {/* Nội dung thẻ */}
                  <div className="p-6">
                    {/* Header với nút back và options */}
                    <div className="flex items-center justify-between mb-6">
                      <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                        <SkipBack className="w-4 h-4 text-white/70" />
                      </div>
                      <span className="text-white/70 text-xs font-medium uppercase tracking-wider">
                        Podcast Tri Ân
                      </span>
                      <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                        <MoreHorizontal className="w-4 h-4 text-white/70" />
                      </div>
                    </div>

                    {/* Ảnh bìa */}
                    <div className="relative aspect-square rounded-2xl overflow-hidden mb-6 shadow-xl">
                      {/* Gradient overlay */}
                      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/60 to-accent/80 z-10" />
                      
                      {/* Pattern nền */}
                      <div className="absolute inset-0 opacity-20 z-20">
                        <svg className="w-full h-full" viewBox="0 0 100 100">
                          <pattern id="lotus-pattern" patternUnits="userSpaceOnUse" width="20" height="20">
                            <circle cx="10" cy="10" r="2" fill="white" fillOpacity="0.3" />
                          </pattern>
                          <rect width="100" height="100" fill="url(#lotus-pattern)" />
                        </svg>
                      </div>

                      {/* Nội dung ảnh bìa */}
                      <div className="absolute inset-0 z-30 flex flex-col items-center justify-center p-8 text-white text-center">
                        {/* Logo hoa sen */}
                        <div className="w-20 h-20 mb-4">
                          <svg viewBox="0 0 64 64" fill="none" className="w-full h-full">
                            <path
                              d="M32 12C30 18 28 24 30 30C32 36 34 38 32 42"
                              stroke="white"
                              strokeWidth="2.5"
                              strokeLinecap="round"
                            />
                            <path
                              d="M20 24C22 28 26 32 30 34C28 30 24 26 20 24Z"
                              stroke="white"
                              strokeWidth="2"
                              fill="white"
                              fillOpacity="0.3"
                            />
                            <path
                              d="M44 24C42 28 38 32 34 34C36 30 40 26 44 24Z"
                              stroke="white"
                              strokeWidth="2"
                              fill="white"
                              fillOpacity="0.3"
                            />
                            <path
                              d="M14 32C18 34 24 36 30 36C24 34 18 32 14 32Z"
                              stroke="white"
                              strokeWidth="2"
                              fill="white"
                              fillOpacity="0.2"
                            />
                            <path
                              d="M50 32C46 34 40 36 34 36C40 34 46 32 50 32Z"
                              stroke="white"
                              strokeWidth="2"
                              fill="white"
                              fillOpacity="0.2"
                            />
                            <path
                              d="M18 48C22 46 28 44 32 44C36 44 42 46 46 48C42 50 36 52 32 52C28 52 22 50 18 48Z"
                              stroke="white"
                              strokeWidth="2"
                              fill="white"
                              fillOpacity="0.25"
                            />
                            <circle cx="32" cy="18" r="4" fill="white" fillOpacity="0.5" />
                          </svg>
                        </div>

                        <h3 className="text-2xl font-bold mb-2">BÚP SEN XANH</h3>
                        <p className="text-sm opacity-80">Gieo Hy Vọng • Vẽ Tương Lai</p>
                        
                        {/* Badge CFE */}
                        <div className="mt-4 px-3 py-1 rounded-full bg-white/20 text-xs">
                          CFE Foundation • NEU
                        </div>
                      </div>
                    </div>

                    {/* Thông tin bài hát */}
                    <div className="mb-4">
                      <h4 className="text-white font-bold text-lg truncate">
                        {getThankMessage()}
                      </h4>
                      <p className="text-white/60 text-sm">Búp Sen Xanh • 2025</p>
                    </div>

                    {/* Thanh tiến trình */}
                    <div className="mb-4">
                      <div className="h-1 bg-white/20 rounded-full overflow-hidden">
                        <div className="h-full w-1/3 bg-primary rounded-full" />
                      </div>
                      <div className="flex justify-between mt-1 text-xs text-white/50">
                        <span>1:23</span>
                        <span>3:45</span>
                      </div>
                    </div>

                    {/* Controls */}
                    <div className="flex items-center justify-between">
                      <Shuffle className="w-5 h-5 text-white/50" />
                      <SkipBack className="w-6 h-6 text-white/70" />
                      <div className="w-14 h-14 rounded-full bg-white flex items-center justify-center">
                        <Play className="w-7 h-7 text-[#1a1a1a] ml-1" />
                      </div>
                      <SkipForward className="w-6 h-6 text-white/70" />
                      <Repeat className="w-5 h-5 text-white/50" />
                    </div>

                    {/* Footer controls */}
                    <div className="flex items-center justify-between mt-6 pt-4 border-t border-white/10">
                      <Heart className="w-5 h-5 text-primary" />
                      <div className="flex items-center gap-2">
                        <Volume2 className="w-4 h-4 text-white/50" />
                        <div className="w-20 h-1 bg-white/20 rounded-full">
                          <div className="h-full w-2/3 bg-white/50 rounded-full" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Nút tải xuống và tạo mới */}
                <div className="flex gap-3">
                  <Button
                    onClick={handleDownload}
                    className="flex-1 h-12 text-base font-medium gap-2"
                  >
                    <Download className="w-5 h-5" />
                    Tải ảnh tri ân
                  </Button>
                  <Button
                    onClick={handleReset}
                    variant="outline"
                    className="h-12 px-6"
                  >
                    Tạo mới
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
